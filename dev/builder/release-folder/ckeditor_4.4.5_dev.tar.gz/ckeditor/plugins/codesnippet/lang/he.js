﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","he",{button:"הכנס קטע קוד",codeContents:"תוכן קוד",emptySnippetError:"קטע קוד לא יכול להיות ריק.",language:"שפה",title:"קטע קוד",pathName:"code snippet"});