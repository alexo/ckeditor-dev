﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'sl', {
	alt: 'Nadomestno besedilo',
	btnUpload: 'Pošlji na strežnik',
	captioned: 'Podnaslovljena slika',
	captionPlaceholder: 'Napis',
	infoTab: 'Podatki o sliki',
	lockRatio: 'Zakleni razmerje',
	menu: 'Lastnosti slike',
	pathName: 'slika',
	pathNameCaption: 'napis',
	resetSize: 'Ponastavi velikost',
	resizer: 'Kliknite in povlecite, da spremeniti velikost',
	title: 'Lastnosti slike',
	uploadTab: 'Naloži',
	urlMissing: 'Manjka vir (URL) slike.'
} );
