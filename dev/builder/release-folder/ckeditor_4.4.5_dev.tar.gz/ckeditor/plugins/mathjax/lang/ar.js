﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'mathjax', 'ar', {
	title: 'Mathematics in TeX', // MISSING
	button: 'Math', // MISSING
	dialogInput: 'Write your TeX here', // MISSING
	docUrl: 'http://en.wikibooks.org/wiki/LaTeX/Mathematics',
	docLabel: 'TeX documentation', // MISSING
	loading: 'تحميل',
	pathName: 'math' // MISSING
} );
