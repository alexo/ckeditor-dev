﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","pt",{title:"Informação do Elemento",dialogName:"Nome da janela do diálogo",tabName:"Nome do Separador",elementId:"Id. do Elemento",elementType:"Tipo de Elemento"});