﻿/**
 * @license Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'codesnippet', 'zh-cn', {
	button: '插入代码',
	codeContents: 'Code content', // MISSING
	emptySnippetError: '插入代码不能为空',
	language: '语言',
	title: 'Code snippet', // MISSING
	pathName: 'code snippet' // MISSING
} );
