﻿/*
 Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","si",{title:"මුලද්‍රව්‍ය ",dialogName:"දෙබස් කවුළුවේ නම",tabName:"තීරුවේ නම",elementId:"මුලද්‍රව්‍ය කේතය",elementType:"මුලද්‍රව්‍ය වර්ගය"});