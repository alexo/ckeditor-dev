﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'docprops', 'si', {
	bgColor: 'පසුබිම් වර්ණය',
	bgFixed: 'Non-scrolling (Fixed) Background', // MISSING
	bgImage: 'පසුබිම් ',
	charset: 'Character Set Encoding', // MISSING
	charsetASCII: 'ASCII',
	charsetCE: 'මාධ්‍ය ',
	charsetCR: 'සිරිලික් හෝඩිය',
	charsetCT: 'චීන සම්ප්‍රදාය',
	charsetGR: 'ග්‍රීක',
	charsetJP: 'ජපාන',
	charsetKR: 'Korean', // MISSING
	charsetOther: 'අනෙකුත් අක්ෂර කොටස්',
	charsetTR: 'තුර්කි',
	charsetUN: 'Unicode (UTF-8)', // MISSING
	charsetWE: 'බස්නාහිර ',
	chooseColor: 'තෝරන්න',
	design: 'Design', // MISSING
	docTitle: 'පිටු මාතෘකාව',
	docType: 'ලිපිගොනු වර්ගයේ මාතෘකාව',
	docTypeOther: 'අනෙකුත් ලිපිගොනු වර්ගයේ මාතෘකා',
	label: 'ලිපිගොනු ',
	margin: 'පිටු සීමාවන්',
	marginBottom: 'පහල',
	marginLeft: 'වම',
	marginRight: 'දකුණ',
	marginTop: 'ඉ',
	meta: 'Meta Tags', // MISSING
	metaAuthor: 'Author', // MISSING
	metaCopyright: 'ප්‍රකාශන ',
	metaDescription: 'ලිපිගොනු ',
	metaKeywords: 'ලිපිගොනු පෙලගේසමේ විශේෂ වචන (කොමා වලින් වෙන්කරන ලද)',
	other: 'අනෙකුත්',
	previewHtml: '<p>This is some <strong>sample text</strong>. You are using <a href="javascript:void(0)">CKEditor</a>.</p>', // MISSING
	title: 'පෝරමයේ ගුණ/',
	txtColor: 'අක්ෂර වර්ණ',
	xhtmlDec: 'Include XHTML Declarations' // MISSING
} );
