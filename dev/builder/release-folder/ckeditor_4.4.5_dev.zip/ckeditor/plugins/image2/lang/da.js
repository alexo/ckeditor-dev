﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'da', {
	alt: 'Alternativ tekst',
	btnUpload: 'Upload fil til serveren',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Generelt',
	lockRatio: 'Lås størrelsesforhold',
	menu: 'Egenskaber for billede',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Nulstil størrelse',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Egenskaber for billede',
	uploadTab: 'Upload',
	urlMissing: 'Kilde på billed-URL mangler'
} );
