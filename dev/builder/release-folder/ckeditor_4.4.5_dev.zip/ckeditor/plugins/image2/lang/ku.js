﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'ku', {
	alt: 'جێگرەوەی دەق',
	btnUpload: 'ناردنی بۆ ڕاژه',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'زانیاری وێنه',
	lockRatio: 'داخستنی ڕێژه',
	menu: 'خاسیەتی وێنه',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'ڕێکخستنەوەی قەباره',
	resizer: 'Click and drag to resize', // MISSING
	title: 'خاسیەتی وێنه',
	uploadTab: 'بارکردن',
	urlMissing: 'سەرچاوەی بەستەری وێنه بزره'
} );
